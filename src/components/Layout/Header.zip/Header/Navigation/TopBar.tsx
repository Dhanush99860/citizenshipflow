"use client";

import Link from "next/link";
import { HiMiniPhone, HiOutlineEnvelope } from "react-icons/hi2";
import { FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";
import { FiLogIn } from "react-icons/fi";
import Search from "@/components/GlobalSearch";

/**
 * TopBar
 * - Visible on >= lg (your Header already hides it on smaller screens)
 * - Three zones: Contact (left) / Search (center) / Social + Login (right)
 * - Clear focus states, subtle motion, and consistent spacing
 * - Uses your brand colors (secondary on hover) and keeps text white
 */
const TopBar = () => {
  // centralize values for easy edits later
  const PHONE_RAW = "+919876543210";
  const PHONE_FMT = "+91 98765 43210";
  const EMAIL = "info@example.com";

  return (
    <div className="hidden lg:block">
      {/* thin divider line so top bar reads cleanly over gradients */}
      <div className="border-b border-white/15">
        <div
          className={[
            "container mx-auto lg:max-w-screen-xl md:max-w-screen-md px-4",
            "grid grid-cols-[auto,1fr,auto] items-center gap-6",
            "py-3 text-sm",
            "text-white",
          ].join(" ")}
        >
          {/* LEFT — Contact actions */}
          <div className="flex items-center gap-6">
            <a
              href={`tel:${PHONE_RAW}`}
              className="group inline-flex items-center gap-2 rounded-lg px-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition"
              aria-label={`Call us at ${PHONE_FMT}`}
            >
              <span className="grid h-8 w-8 place-items-center rounded-full bg-white text-secondary shadow-sm transition group-hover:bg-secondary group-hover:text-white">
                <HiMiniPhone className="text-base" aria-hidden="true" />
              </span>
              <span className="font-medium transition-colors group-hover:text-secondary">
                {PHONE_FMT}
              </span>
            </a>

            <a
              href={`mailto:${EMAIL}`}
              className="group inline-flex items-center gap-2 rounded-lg px-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary transition"
              aria-label={`Email us at ${EMAIL}`}
            >
              <span className="grid h-8 w-8 place-items-center rounded-full bg-white text-secondary shadow-sm transition group-hover:bg-secondary group-hover:text-white">
                <HiOutlineEnvelope className="text-base" aria-hidden="true" />
              </span>
              <span className="font-medium transition-colors group-hover:text-secondary">
                {EMAIL}
              </span>
            </a>
          </div>

          {/* CENTER — Global Search (kept flexible, won’t squish) */}
          <div className="flex min-w-[320px] justify-center">
            <div className="w-full max-w-[560px]">
              <Search />
            </div>
          </div>

          {/* RIGHT — Social + Login */}
          <div className="flex items-center gap-3">
            <nav aria-label="Social links">
              <ul className="flex items-center gap-3">
                {[
                  {
                    href: "https://facebook.com/xiphiasimmigration",
                    label: "Facebook",
                    Icon: FaFacebookF,
                  },
                  {
                    href: "https://twitter.com/xiphiasimmigra",
                    label: "Twitter",
                    Icon: FaTwitter,
                  },
                  {
                    href: "https://instagram.com/xiphiasimmigration",
                    label: "Instagram",
                    Icon: FaInstagram,
                  },
                ].map(({ href, label, Icon }) => (
                  <li key={label}>
                    <a
                      href={href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Visit our ${label} page`}
                      className={[
                        "grid h-9 w-9 place-items-center rounded-full",
                        "bg-white/20 text-white shadow-sm",
                        "transition duration-200 hover:scale-110 hover:bg-secondary",
                        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary",
                      ].join(" ")}
                    >
                      <Icon size={14} aria-hidden="true" />
                    </a>
                  </li>
                ))}
              </ul>
            </nav>

            <Link
              href="/login"
              aria-label="Login to your account"
              className={[
                "ml-2 inline-flex items-center gap-2 rounded-lg border border-white px-4 py-1",
                "text-[15px] font-medium text-white",
                "transition duration-200 hover:bg-secondary hover:text-white hover:shadow-lg",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary",
              ].join(" ")}
            >
              <FiLogIn className="text-base" aria-hidden="true" />
              Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
