"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { useTheme } from "next-themes";
import { Icon } from "@iconify/react/dist/iconify.js";

import TopBar from "@/components/Layout/Header/Navigation/TopBar";
import { headerData } from "../Header/Navigation/menuData";
import Logo from "./Logo";
import LogoWhite from "./LogoWhite";
import HeaderLink from "../Header/Navigation/HeaderLink";
import MobileHeaderLink from "../Header/Navigation/MobileHeaderLink";
import Search from "@/components/GlobalSearch";

import { HiMiniPhone, HiOutlineEnvelope } from "react-icons/hi2";
import { FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";
import { FiLogIn } from "react-icons/fi";

/**
 * Smart sticky header:
 * - TopBar is visible initially on desktop but collapses after scrolling.
 * - Navbar row shrinks and remains fixed.
 * - Mobile drawer locks body scroll.
 * - Search popover for quick access (esp. when TopBar is collapsed).
 */
const Header: React.FC = () => {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [compact, setCompact] = useState(false); // true after scrollY > 80

  // refs
  const drawerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  // ---------------------------
  // Scroll: compact mode toggle
  // ---------------------------
  useEffect(() => {
    const onScroll = () => setCompact(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // ---------------------------
  // Outside click handlers
  // ---------------------------
  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (drawerOpen && drawerRef.current && !drawerRef.current.contains(t)) {
        setDrawerOpen(false);
      }
      if (searchOpen && searchRef.current && !searchRef.current.contains(t)) {
        setSearchOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [drawerOpen, searchOpen]);

  // ----------------------------------
  // Lock body scroll for overlays
  // ----------------------------------
  useEffect(() => {
    const lock = drawerOpen;
    document.body.style.overflow = lock ? "hidden" : "";
    document.documentElement.style.overflow = lock ? "hidden" : "";
  }, [drawerOpen]);

  // ----------------------------------
  // Derived styles
  // ----------------------------------
  const showTopBar = useMemo(() => !compact, [compact]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 w-full transition-colors duration-300
        ${compact
          ? "bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-500 dark:from-blue-900 dark:via-indigo-800 dark:to-black shadow-lg backdrop-blur-md"
          : "bg-blue-500/80 dark:bg-blue-700/60 backdrop-blur-md"}
      `}
    >
      {/* ---------- Desktop TopBar (collapsible) ---------- */}
      <div
        className={`hidden lg:block overflow-hidden transition-[max-height,opacity] duration-300
        ${showTopBar ? "max-h-16 opacity-100" : "max-h-0 opacity-0"}`}
        aria-hidden={!showTopBar}
      >
        <TopBar />
      </div>

      {/* ---------- Main Navbar Row ---------- */}
      <div className="w-full">
        <div className="container mx-auto lg:max-w-screen-xl md:max-w-screen-md px-3 lg:px-4">
          <div
            className={`grid grid-cols-12 items-center gap-2 lg:gap-4 transition-[height,padding] duration-300
            ${compact ? "h-14 py-0" : "h-20 py-0"}`}
          >
            {/* Logo (kept perfectly aligned on all breakpoints) */}
            <div className="col-span-6 sm:col-span-4 lg:col-span-3 flex items-center">
              <Link href="/" aria-label="Go to homepage" className="block">
                {/* Slightly smaller on mobile to save vertical space */}
                <div className="origin-left scale-[0.9] sm:scale-100">
                  <LogoWhite />
                </div>
              </Link>
            </div>

            {/* Desktop Nav */}
            <nav
              className="hidden lg:flex col-span-6 lg:col-span-6 items-center justify-center gap-6"
              aria-label="Main navigation"
            >
              {headerData.map((item, i) => (
                <HeaderLink key={i} item={item} />
              ))}
            </nav>

            {/* Actions (theme, search, booking, burger) */}
            <div className="col-span-6 sm:col-span-8 lg:col-span-3 flex items-center justify-end gap-2 lg:gap-3">
              {/* Theme */}
              <button
                aria-label="Toggle theme"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className={`flex h-9 w-9 items-center justify-center rounded-lg transition-colors
                  ${pathname === "/" && !compact ? "text-white" : "text-white"}`}
              >
                {theme === "dark" ? (
                  <Icon icon="mdi:white-balance-sunny" className="h-5 w-5 text-yellow-300" />
                ) : (
                  <Icon icon="mdi:moon-waning-crescent" className="h-5 w-5" />
                )}
              </button>

              {/* Search toggle (works on all sizes; extra useful when TopBar is collapsed) */}
              <div className="relative" ref={searchRef}>
                <button
                  aria-label="Open search"
                  onClick={() => setSearchOpen((s) => !s)}
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-white"
                >
                  <Icon icon="mdi:magnify" className="h-5 w-5" />
                </button>

                {/* Popover */}
                {searchOpen && (
                  <div
                    className="absolute right-0 mt-2 w-[min(92vw,520px)] rounded-xl border border-white/20 bg-white/95 dark:bg-darklight/95 shadow-xl p-3 backdrop-blur-md"
                    role="dialog"
                    aria-label="Site search"
                  >
                    <Search />
                  </div>
                )}
              </div>

              {/* Desktop CTAs */}
              <Link
                href="/PersonalBooking"
                className="hidden lg:inline-flex bg-secondary text-white hover:bg-transparent hover:text-white border border-secondary px-4 py-2 rounded-lg transition-colors"
                aria-label="Book a personal consultation"
              >
                Book a Personal Consultation
              </Link>

              {/* Burger (mobile) */}
              <button
                onClick={() => setDrawerOpen(true)}
                className="inline-flex lg:hidden h-10 w-10 items-center justify-center rounded-lg"
                aria-label="Open menu"
                aria-expanded={drawerOpen}
              >
                <span className="sr-only">Open menu</span>
                <span className="block h-0.5 w-6 bg-white" />
                <span className="block h-0.5 w-6 bg-white mt-1.5" />
                <span className="block h-0.5 w-6 bg-white mt-1.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ---------- Overlays (mobile) ---------- */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
          aria-hidden
          onClick={() => setDrawerOpen(false)}
        />
      )}

      {/* Drawer */}
      <div
        ref={drawerRef}
        className={`fixed top-0 right-0 z-50 h-[100dvh] w-[84%] max-w-[360px]
          translate-x-full bg-white dark:bg-darklight shadow-xl rounded-l-2xl
          transition-transform duration-300 ${drawerOpen ? "!translate-x-0" : ""}`}
        role="dialog"
        aria-label="Mobile navigation"
      >
        {/* Drawer header */}
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 p-4 pt-[max(1rem,env(safe-area-inset-top))]">
          <Link href="/" onClick={() => setDrawerOpen(false)} aria-label="Go to homepage">
            <div className="scale-90">
              <Logo />
            </div>
          </Link>
          <button
            onClick={() => setDrawerOpen(false)}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Close menu"
          >
            <Icon icon="tabler:x" className="h-6 w-6 text-primary dark:text-white" />
          </button>
        </div>

        {/* Drawer body */}
        <div className="flex h-[calc(100dvh-64px)] flex-col overflow-y-auto">
          {/* Search (mobile full width) */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <Search />
          </div>

          {/* Nav tree */}
          <nav className="flex flex-col p-4 space-y-2" role="menu">
            {headerData.map((item, i) => (
              <MobileHeaderLink key={i} item={item} closeMenu={() => setDrawerOpen(false)} />
            ))}
          </nav>

          {/* CTA */}
          <div className="px-4">
            <Link
              href="/PersonalBooking"
              onClick={() => setDrawerOpen(false)}
              className="mt-2 inline-flex w-full items-center justify-center rounded-lg bg-primary px-4 py-2 font-semibold text-white shadow hover:bg-blue-700 transition-colors"
              aria-label="Book a personal consultation"
            >
              Book a Personal Consultation
            </Link>
          </div>

          {/* Contact + Social */}
          <div className="mt-4 px-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
            <div className="flex flex-col items-start gap-3">
              <div className="flex items-center gap-2 group">
                <span className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-secondary group-hover:bg-secondary group-hover:text-white transition-colors">
                  <HiMiniPhone className="text-lg" />
                </span>
                <a href="tel:+919876543210" className="font-medium group-hover:text-secondary">
                  +91 98765 43210
                </a>
              </div>
              <div className="flex items-center gap-2 group">
                <span className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-secondary group-hover:bg-secondary group-hover:text-white transition-colors">
                  <HiOutlineEnvelope className="text-lg" />
                </span>
                <a href="mailto:info@example.com" className="font-medium group-hover:text-secondary">
                  info@example.com
                </a>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-3">
              <Link
                href="https://facebook.com/xiphiasimmigration"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 transition hover:scale-110"
              >
                <FaFacebookF size={14} />
              </Link>
              <Link
                href="https://twitter.com/xiphiasimmigra"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Twitter"
                className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 transition hover:scale-110"
              >
                <FaTwitter size={14} />
              </Link>
              <Link
                href="https://instagram.com/xiphiasimmigration"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 transition hover:scale-110"
              >
                <FaInstagram size={14} />
              </Link>
            </div>

            <button
              aria-label="Login"
              className="mt-4 inline-flex items-center gap-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-1.5 text-[15px] font-medium text-gray-800 dark:text-white hover:bg-gray-800 dark:hover:bg-primary hover:text-white transition-colors shadow-sm"
            >
              <FiLogIn className="text-lg" />
              Login
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
