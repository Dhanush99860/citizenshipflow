export interface Award {
    id: number;
    title: string;
    img: string;
  }
  
  const awardsData: Award[] = [
    { id: 1, title: "Global Excellence Award", img: "/images/awards/1.jpg" },
    { id: 2, title: "Best Immigration Firm 2024", img: "/images/awards/1.jpg" },
    { id: 3, title: "Innovation in Consultancy", img: "/images/awards/1.jpg" },
    { id: 4, title: "Top Client Satisfaction", img: "/images/awards/1.jpg" },
    { id: 5, title: "Leadership Recognition", img: "/images/awards/1.jpg" },
    { id: 6, title: "Excellence in Service", img: "/images/awards/1.jpg" },
    { id: 7, title: "Outstanding Support Award", img: "/images/awards/1.jpg" },
    { id: 8, title: "Industry Leadership 2025", img: "/images/awards/1.jpg" },
    { id: 9, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 10, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 11, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 12, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 13, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 14, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 15, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 16, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 17, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 18, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },
    { id: 19, title: "Trusted Brand Award", img: "/images/awards/1.jpg" },

  ];
  
  export default awardsData;
  