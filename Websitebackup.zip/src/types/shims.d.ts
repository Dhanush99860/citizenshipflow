declare module "next-mdx-remote/rsc" {
    const compileMDX: any;
    export default compileMDX;
  }
  